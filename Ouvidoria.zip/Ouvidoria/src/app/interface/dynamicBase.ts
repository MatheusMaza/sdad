import { PoDynamicFormField, PoDynamicViewField } from "@po-ui/ng-components";

export interface IPortalFormInterfaceBase{
    fields: PoDynamicFormField[];
    dados: any[] | any;
}

export interface IPortalFormInterfaceView{
    fields: PoDynamicViewField[];
    dados: any[] | any;
}