import { CommonModule } from '@angular/common';
import { Component, ViewEncapsulation } from '@angular/core';
import { PoLoadingModule } from '@po-ui/ng-components';
import { LoaderService } from '../../services/loader.service';

@Component({
  selector: 'app-load',
  standalone: true,
  imports: [
    CommonModule,
    PoLoadingModule 
  ],
  templateUrl: './loading-overlay.component.html',
  styleUrl: './loading-overlay.component.scss'
})
export class LoadingOverlayComponent {

  constructor(public loader: LoaderService) {}

}
