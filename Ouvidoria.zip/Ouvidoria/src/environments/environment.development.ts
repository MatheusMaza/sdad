export const environment = {
    urlToken: 'http://10.1.100.39:3000/auth/getToken',
};
