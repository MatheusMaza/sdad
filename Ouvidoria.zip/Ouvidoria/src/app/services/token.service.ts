import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  private _urlToken = environment.urlToken;
  
  constructor(
    private http: HttpClient,
  ) { }

  getToken(): Observable<any> {
    return this.http.get<any>(this._urlToken, this.headerGetToken)
  }

  headerGetToken = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'skip': 'true',
    })
  }
}
