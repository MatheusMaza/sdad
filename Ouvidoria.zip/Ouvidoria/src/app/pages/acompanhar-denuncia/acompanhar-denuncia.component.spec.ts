import { ComponentFixture, TestBed } from '@angular/core/testing';

import { acompanharDenuncia } from './acompanhar-denuncia.component';

describe('NovaDenunciaComponent', () => {
  let component: acompanharDenuncia;
  let fixture: ComponentFixture<acompanharDenuncia>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [acompanharDenuncia]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(acompanharDenuncia);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
