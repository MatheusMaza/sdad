export interface IDenuncia {
    identi: boolean;
    unidad: string;
    nome: string;                    
    ocorre: string;                  
    ocoinf: string;                  
    pesenv: string;                  
    dataocor: string;                
    horaocor: string;                
    recorr: string;                  
    cieoco: string;                  
    sabeoco: string;                 
    relato: string;                  
    observ: string;                  
    datint?: string;
    termace: string; 
    anexo1?: string;
    anexo2?: string;
    anexo3?: string;
    anexo4?: string;
    anexo5?: string;
}