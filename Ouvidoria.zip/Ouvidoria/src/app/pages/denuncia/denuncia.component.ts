import { Component, Input, input, OnChanges, OnInit, SimpleChanges, viewChild, ViewChild, ViewRef } from '@angular/core';
import { Router } from '@angular/router';
import { PoBreadcrumbItem, PoDialogConfirmOptions, PoDialogService, PoDynamicFormComponent, PoDynamicFormFieldChanged, PoDynamicFormValidation, PoModalComponent, PoModalModule, PoModule, PoNotificationService, PoRadioGroupOption } from '@po-ui/ng-components';
import { PoDividerModule } from '@po-ui/ng-components';
import { PoFieldModule } from '@po-ui/ng-components';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule} from '@angular/common';
import { PoButtonModule } from '@po-ui/ng-components';
import { PoDynamicModule } from '@po-ui/ng-components';
import { IDenuncia } from '../../interface/denuncia';
import { FieldsService } from '../../services/fields.service';
import { IPortalFormInterfaceBase } from '../../interface/dynamicBase';
import { PoWidgetModule } from '@po-ui/ng-components';
import { PoDialogModule } from '@po-ui/ng-components';
import { PoBreadcrumbModule } from '@po-ui/ng-components';
import { catchError, first } from 'rxjs';
import { TokenService } from '../../services/token.service';
import { OuvidoriaService } from '../../services/ouvidoria.service';
import { IdenunciaPayload } from '../../interface/denuncia-payload.interface';
import { ImagensComponent } from '../../componentes/imagens/imagens.component';
import { PoAccordionModule } from '@po-ui/ng-components';
import {ClipboardModule} from '@angular/cdk/clipboard';
import {DialogModule} from '@angular/cdk/dialog';

@Component({
  selector: 'app-denuncia',
  standalone: true,
  imports: [
    PoModalModule,
    PoFieldModule,
    CommonModule,
    FormsModule,
    PoButtonModule,
    PoDividerModule,
    PoDynamicModule,
    PoWidgetModule,
    PoDialogModule,
    PoBreadcrumbModule,
    ImagensComponent,
    PoAccordionModule,
    ClipboardModule,
    DialogModule,

  ],
  templateUrl: './denuncia.component.html',
  styleUrl: './denuncia.component.scss'
})
export class DenunciaComponent implements OnInit {

  base64String: string[] = []
  numProtocolo: string = ""
  mensagemAnoteProtocolo: string = "Concluído! Seu relato será tratado por uma equipe especializada e experiente. Para consultar o andamento, salve este número!"
  mensagemProtocoloSucesso: string = ""
  deveExibirProtocolo: boolean = false

  opcoesTermo: PoRadioGroupOption [] = [
    { label: 'Sim, estou ciente', value: "1"},
    { label: 'Não', value: "0" }
  ];

  infoDialogOptions: PoDialogConfirmOptions = {
    close: () => this.voltarTelaHome(),
    confirm: () => this.voltarTelaHome(),
    literals: {cancel: ''},
    title: '',
    message: '',
  }

  opcaoBreadcrumb: PoBreadcrumbItem[] = [
    { label: 'Home', link: '/' },
    { label: 'Relato', link: '/novoRelato' }
  ]

  exibeForm: boolean = false;
  acaoContinuar: boolean = false;
  denunciaForm!: IPortalFormInterfaceBase;
  denunciaPayload!: IdenunciaPayload;
  formRelato?: NgForm;
  denunciaValue?: IDenuncia;
  validateFields: string[] = ["ident", "nome", "unidad", "tocorr", "ocoinf", "pesenv", "dataocor", "horaocor", "recorr", "cieoco", "sabeoco", "relato", "termace"];

  @ViewChild('modalTermo', {static: true}) modalTermo!: PoModalComponent;
  @ViewChild(PoDynamicFormComponent, { static: true }) preenchimentoForm!: PoDynamicFormComponent;
  @ViewChild('protocoloModal', {static: true}) protocoloModal!: PoModalComponent;



  constructor(
    private router: Router,
    private _DynamicForm: FieldsService,
    public poDialog: PoDialogService,
    private tokenService: TokenService,
    private ouvidoriaService: OuvidoriaService,
    private poNotification: PoNotificationService,
  )
  {}


  ngOnInit() {
    this.modalTermo.open();

    this.denunciaValue = {
      identi: false,
      nome: "",
      unidad: "",
      ocorre: "",
      ocoinf: "",
      pesenv: "",
      dataocor: "",
      horaocor: "",
      recorr: "",
      cieoco: "",
      sabeoco: "",
      relato: "",
      observ: "",
      datint: "",
      termace: "Sim",
    }
    this.denunciaForm = {
      fields: this._DynamicForm.getFieldsRelato(),
      dados: this.denunciaValue
    };

    this.tokenService.getToken().pipe(
      catchError((err) => {
        console.error(err);
        this.poNotification.error('Não foi possivel abrir um novo relato, tente novamente em alguns instantes.')
        this.router.navigate([''])
        return [];
      })
    )
    .subscribe((dataToken: any) => {
      window.sessionStorage.setItem('access_token', dataToken.access_token);
      window.sessionStorage.setItem('refresh_token', dataToken.refresh_token);
      window.sessionStorage.setItem('token_type', dataToken.token_type);

    })
  }

  async onUploadFiles(event: any) {

    const input = event.target as HTMLInputElement;
    const files = Array.from(input.files || []);
    const maxFiles = 5;

    if (this.base64String.length + files.length > maxFiles) {
      this.poNotification.warning('Você pode enviar no máximo 5 arquivos.');
      input.value = '';
      return

    }

    for (const file of files) {
      if (file) {
        const base64String = await this.readFileAsDataURL(file);
        
        // Verifica se o arquivo é uma imagem ou um PDF
        if (file.type.startsWith('image/') || file.type === 'application/pdf') {
          this.base64String.push(base64String);
        } else {
          this.poNotification.error('Tipo de arquivo não suportado: ' + file.type);
        }
      }
    }

    this.atualizarAnexos();
  }

  readFileAsDataURL(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        resolve(reader.result as string);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  atualizarAnexos() {
    if (this.base64String.length > 0) {
      for (let i = 0; i < this.base64String.length; i++) {
        this.denunciaForm.dados[`anexo${i + 1}`] = this.base64String[i];
      }
    }
  }

  onChangeFields(valorAlteerado: PoDynamicFormFieldChanged) :PoDynamicFormValidation {
    if(valorAlteerado.value.ident == 'Sim'){
      return {
        value: {nome: this.denunciaValue?.nome},
        fields:
        [
          {
            property: 'nome',
            gridColumns: 9,
            gridSmColumns: 12,
            disabled: false,
            visible: true,
            required: true,
          },
        ]
      }
    } else if(valorAlteerado.value.ident == 'Não'){
      return {
        value: {nome: undefined},
        fields: [{
          property: 'nome',
          gridColumns: 7,
          gridSmColumns: 12,
          disabled: true,
          visible: false,
          required: false
        }]
      }
    } else {
      return valorAlteerado;
    }
  }

  getForm(event: any){
    this.formRelato = event;

  }

  checagemTermos(event: any){
    let selecao = event;

    if(selecao === "1"){
      this.acaoContinuar = true;
    } else{
      this.acaoContinuar = false;
    }
  }

  onContinuarClick(): void {
    this.modalTermo.close();
    this.exibeForm = true;
  }

  onRejeitarClick(): void {
    this.voltarTelaHome();
    this.exibeForm = false;
  }

  voltarTelaHome(): void{
    this.modalTermo.close();
    this.router.navigate([''])
  }

  abrirDialog(): void{
    const formValue = this.formRelato?.form.value;
    formValue.termace = this.denunciaValue?.termace;

    if (this.base64String.length > 0) {
      for (let i = 0; i < this.base64String.length; i++) {
        this.denunciaForm.dados[`anexo${i + 1}`] = this.base64String[i];
      }
    }

    this.denunciaValue =  this.formRelato?.form.value;

    Object.assign({},this.denunciaForm.dados);
    const relatoPayload: IdenunciaPayload = {
      opcao: {
        nopc: 3
      },
      ouvidoria: this.denunciaForm.dados
    };

    this.ouvidoriaService.gravaRelato(relatoPayload).pipe(
      catchError((err) => {
        console.error(err);
        this.poNotification.error('Não foi realizar o Relato, Tente novamente mais Tarde.')
        return [];
      })
    ).subscribe((res) => {
      this.deveExibirProtocolo = true;
      this.numProtocolo = res.numprot;
      this.mensagemProtocoloSucesso = res.message;
      
    })
  }

  onClipBoardClick(){
    this.poNotification.success({
      message: 'Protocolo copiado com Sucesso',
      duration: 3000
    })
  }
}
