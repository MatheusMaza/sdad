import { IDenuncia } from "./denuncia";

export interface IdenunciaPayload {
    opcao: IOpcao,
    ouvidoria: IDenuncia | undefined
}

export interface IOpcao {
    nopc: string | number
}
