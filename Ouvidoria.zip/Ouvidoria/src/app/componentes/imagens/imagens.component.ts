import { Component, Input, input } from '@angular/core';
import { PoImageModule } from '@po-ui/ng-components';
import { PoButtonModule } from '@po-ui/ng-components';

@Component({
  selector: 'app-imagens',
  standalone: true,
  imports: [
    PoImageModule,
    PoButtonModule
  ],
  templateUrl: './imagens.component.html',
  styleUrl: './imagens.component.scss'
})
export class ImagensComponent {
  @Input() arquivos!: string[];
  @Input() deveMostrarDeletar: boolean = true;
  
  deletarImagem(index: number){
    this.arquivos.splice(index, 1)
  }

  abrirArquivo(arquivoBase64: string) {
    const isPdf = arquivoBase64.startsWith('data:application/pdf')

    if(isPdf){
      const pdfAbrir = window.open("");
      pdfAbrir?.document.write(
        `<iframe width='100%' height='100%' src='${arquivoBase64}'></iframe>`
      )
    } else {
      const newWindow = window.open();
      newWindow?.document.write('<img src="' + arquivoBase64 + '" alt="Imagem">');
    }
  }
}
