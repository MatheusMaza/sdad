import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OuvidoriaService {

  constructor(
    private http: HttpClient,
  ) { }

  gravaRelato(relato: any): Observable<any> {
    const urlGrava = 'https://emaza.com.br:12291/sandbox/rest0901/WSDLMZ543/grvdados?codemp=09&codfil=01';
    return this.http.post<any>(urlGrava, relato);
  }

  consultaRelato(numProtocolo: string): Observable<any> {
    const urlConsulta = `https://emaza.com.br:12291/sandbox/rest0901/WSDLMZ543/histcon?pronum=${numProtocolo}`;
    return this.http.get<any>(urlConsulta);
  }

  gravaInteracao(interacaoPayload: any): Observable<any> {
    const urlInteracao = `https://emaza.com.br:12291/sandbox/rest0901/WSDLMZ543/grvint?nosnum=${interacaoPayload.nosnum}`;
    return this.http.post<any>(urlInteracao, interacaoPayload)
  }
}
