import { Injectable } from '@angular/core';
import { PoDynamicFormField, PoDynamicViewField} from '@po-ui/ng-components';

@Injectable({
  providedIn: 'root'
})
export class FieldsService {

  getDataAtualFormatada(): string {
    let hoje = new Date();
    let dia = String(hoje.getDate()).padStart(2, "0");
    let mes = String(hoje.getMonth() + 1).padStart(2, "0");
    let ano = hoje.getFullYear();

    return `${ano}-${mes}-${dia}`
  }

  getFieldsRelato(): Array<PoDynamicFormField> {
    return [
      {
        divider: 'Identificação',
        property: 'ident',
        label: 'Você deseja se identificar?',
        gridXlColumns: 3,
        gridLgColumns: 3,
        gridMdColumns: 3,
        gridSmColumns: 12,
        type: 'boolean',
        booleanTrue: 'Sim',
        booleanFalse: 'Não',
        formatModel: true,
        order: 1
      },
      {
        property: 'nome',
        label: 'Se Sim, qual seu nome?',
        gridColumns: 6,
        gridSmColumns: 6,
        placeholder: 'Digite o nome',
        order: 2,
        type: 'string',
        fieldLabel: 'nome',
        disabled: true,
        visible: false
      },
      {
        property: 'unidad',
        label: 'Qual sua Unidade?',
        required: true,
        gridColumns: 12,
        gridSmColumns: 12,
        options: [
          { label: 'Escandinavia Ribeirao Preto' , code: '0901' },
          { label: 'Escandinavia Sao Jose do Rio Preto' , code: '0904' },
          { label: 'Escandinavia Araraquara' , code: '0905' },
          { label: 'Escandinavia Uberlandia' , code: '0906' },
          { label: 'Escandinavia Sta Vitoria' , code: '0908' },
          { label: 'Escandinavia Uberaba' , code: '0909' },
          { label: 'Escandinavia Local Recapadora' , code: '0910' },
          { label: 'Escandinavia Patriocino' , code: '0911' },
          { label: 'Cotave Sao Jose do Rio Preto' , code: '0401' },
          { label: 'Cotave Catanduva' , code: '0403' },
          { label: 'Cotave Votuporanga' , code: '0404' },
          { label: 'Elmaz Belo Horizonte' , code: '2001' },
          { label: 'Local Truck Sao Jose do Rio Preto' , code: '2501' },
          { label: 'Local Truck Uberlandia' , code: '2502' },
          { label: 'Digap Sao Jose do Rio Preto' , code: '2601' },
          { label: 'Digap Sao Jose do Rio Preto' , code: '2602' },
          { label: 'Digap Belo Horizonte' , code: '2603' },
          { label: 'Tarraf Corretora Sao Jose do Rio Preto' , code: '2701' },
          { label: 'Maza Transportes Sao Jose do Rio Preto' , code: '2801' },
          { label: 'Mister Truck Sao Jose do Rio Preto' , code: '2901' },
          { label: 'Mister Truck Belo Horizonte' , code: '2902' },
          { label: 'Mister Truck Uberlandia' , code: '2903' }
        ],
        order: 3,
        fieldLabel: 'label',
        placeholder: 'Selecione a Unidade',
        fieldValue: 'code'
      },
      {
        divider: 'Relato',
        property: 'tocorr',
        label: 'Tipo do fato:',
        required: true,
        gridColumns: 12,
        gridSmColumns: 12,
        optional: false,
        options: [
          { label: "Fraude", code: "01" },
          { label: "Descumprimento aos processos e políticas internas", code: "02" },
          { label: "Não conformidade ao Código de Ética e Conduta", code: "03" },
          { label: "Destruição, danos ou uso indevido de ativos", code: "04" },
          { label: "Roubo, furto ou desvios de materiais", code: "05" },
          { label: "Favorecimento ou conflito de interesses", code: "06" },
          { label: "Assédio Sexual", code: "07" },
          { label: "Violação a leis ambientais", code: "08" },
          { label: "Assédio Moral, Agressão Física ou Discriminação", code: "09" },
          { label: "Violação a leis trabalhistas", code: "10" },
          { label: "Uso ou tráfico de substâncias proibidas", code: "11" },
          { label: "Vazamento ou Uso indevido de informações", code: "12" },
          { label: "Favorecimento a atividades internas, promoção e recrutamento", code: "13" },
          { label: "Relacionamento íntimo com subordinação direta", code: "14" },
          { label: "Desvio de comportamento", code: "15" },
          { label: "Outros", code: "16" }
        ],
        placeholder: 'Selecione o tipo do fato',
        optionsMulti: false,
        order: 4,
        fieldValue: 'code',
        fieldLabel: 'label',
      },
      {
        property: 'ocoinf',
        label: 'Sobre o fato você tem:',
        required: true,
        gridColumns: 6,
        gridSmColumns: 12,
        options: [
          {label: 'Certeza', value: '1'},
          {label: 'Suspeita', value: '2'},
          {label: 'Ouviu dizer', value: '3'}
        ],
        type: 'boolean',
        order: 5
      },
      {
        property: 'pesenv',
        label: 'É possível identificar pessoas envolvidas? Quais?',
        required: true,
        gridColumns: 12,
        gridSmColumns: 12,
        placeholder: 'Liste as pessoas envolvidas',
        order: 6,
        rows: 4,
        type: 'string'
      },
      {
        divider: 'Periodo',
        property: 'dataocor',
        label: 'Qual data o fato aconteceu?',
        required: false,
        gridColumns: 6,
        gridSmColumns: 12,
        placeholder: 'Selecione a data',
        optional: true,
        order: 7,
        type: 'date',
        format: 'dd/mm/yyyy',
        maxValue: this.getDataAtualFormatada()
      },
      {
        property: 'horaocor',
        label: 'Qual horário o fato aconteceu?',
        required: false,
        gridColumns: 6,
        gridSmColumns: 12,
        optional: true,
        placeholder: 'Preencha a hora',
        order: 8,
        type: 'time',
      },
      {
        divider: 'MAIS INFORMAÇÕES',
        property: 'recorr',
        label: 'Existe recorrência deste fato?',
        required: true,
        gridColumns: 6,
        gridSmColumns: 12,
        options: [
          {label:'Sim', value: "1"},
          {label:'Não', value:"0"},
          {label:'Não sei', value:"2"}
        ],
        type: 'boolean',
        order: 9
      },
      {
        property: 'cieoco',
        label: 'Você considera que a supervisão, gerência ou diretoria, acima das pessoas envolvidas no relato, estão cientes desse fato? Se sim, quais os nomes das pessoas?',
        required: true,
        gridColumns: 6,
        gridSmColumns: 12,
        placeholder: 'Informe se há ciência da superior',
        order: 10,
        rows: 4,
        type: 'string'
      },
      {
        property: 'sabeoco',
        label: 'Como ficou sabendo deste fato?',
        required: true,
        gridXlColumns: 6,
        gridLgColumns: 12,
        gridMdColumns: 12,
        gridSmColumns: 12,
        placeholder: 'Quem está sabendo do fato',
        order: 11,
        rows: 4,
        type: 'string'
      },
      {
        property: 'relato',
        label: 'Descreva abaixo seu relato, com o máximo de informações possíveis.',
        required: true,
        gridXlColumns: 6,
        gridLgColumns: 12,
        gridMdColumns: 12,
        gridSmColumns: 12,
        placeholder: 'Digite o relato do usuário',
        order: 12,
        rows: 4,
        type: 'string',
      },
      {
        property: 'termace',
        label: 'termo de aceite',
        visible: false,
        order: 13,
      },
      {
        property: "anexo1",
        visible: false,
        type: 'string'
      },
      {
        property: "anexo2",
        visible: false,
        type: 'string'
      },
      {
        property: "anexo3",
        visible: false,
        type: 'string'
      },
      {
        property: "anexo4",
        visible: false,
        type: 'string'
      },
      {
        property: "anexo5",
        visible: false,
        type: 'string'
      },

    ]
  }

  getViewAcompanhamento(): Array<PoDynamicViewField> {
    return [
      {
        property: 'filial',
        label: 'Filial',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 1,
        type: 'string',
        visible: false
      },
      {
        property: 'nosnum',
        label: 'Número de NOS',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 2,
        type: 'string',
        visible: false
      },
      {
        property: 'numpro',
        label: 'Número do Protocolo',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 3,
        type: 'string',
        visible: false
      },
      {
        property: 'unidad',
        label: 'Unidade',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 4,
        type: 'string'
      },
      {
        divider: 'Relato',
        property: 'ocorre',
        label: 'Tipo do fato',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 5,
        type: 'string'
      },
      {
        property: 'ocoinf',
        label: 'Sobre o fato você tem:',
        gridColumns: 6,
        gridSmColumns: 12,
        order: 6,
        type: 'boolean'
      },
      {
        property: 'pssenv',
        label: 'É possível identificar pessoas envolvidas? Quais?',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 7,
        type: 'string'
      },
      {
        divider: 'Período',
        property: 'datoco',
        label: 'Data do fato',
        gridColumns: 6,
        gridSmColumns: 12,
        order: 8,
        type: 'date',
      },
      {
        property: 'horoco',
        label: 'Hora do fato',
        gridColumns: 6,
        gridSmColumns: 12,
        order: 9,
        type: 'text',
        format: '99:99'
      },
      {
        divider: 'MAIS INFORMAÇÕES',
        property: 'recorr',
        label: 'Existe recorrência desse fato?',
        gridColumns: 6,
        gridSmColumns: 12,
        order: 10,
        type: 'boolean'
      },
      {
        property: 'cieoco',
        label: 'A supervisão, gerência ou diretoria está ciente do fato? Se sim, quais os nomes das pessoas?',
        gridColumns: 6,
        gridSmColumns: 12,
        order: 11,
        type: 'string'
      },
      {
        property: 'saboco',
        label: 'Como ficou sabendo deste fato?',
        gridXlColumns: 6,
        gridLgColumns: 12,
        gridMdColumns: 12,
        gridSmColumns: 12,
        order: 12,
        type: 'string'
      },
      {
        property: 'relato',
        label: 'Descreva seu relato, com o máximo de informações possíveis.',
        gridXlColumns: 6,
        gridLgColumns: 12,
        gridMdColumns: 12,
        gridSmColumns: 12,
        order: 13,
        type: 'string'
      },
      {
        divider: 'Registro',
        property: 'datreg',
        label: 'Data de Registro',
        gridColumns: 6,
        gridSmColumns: 12,
        order: 14,
        type: 'date',
        visible: true
      },
      {
        property: 'horreg',
        label: 'Hora de Registro',
        gridColumns: 6,
        gridSmColumns: 12,
        order: 15,
        type: 'text',
        format: '99:99',
        visible: true
      },
      {
        property: 'termo',
        label: 'Termo de Consentimento',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 16,
        type: 'string',
        visible: false
      },
      {
        property: 'imagens',
        type: 'string',
        visible: false
      }
    ];
  }

  getinteracoesAcomp(): Array<PoDynamicFormField> {
    return [
      {
        property: 'filial',
        label: 'Filial',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 1,
        type: 'string',
        visible: false
      },
      {
        property: 'nosnum',
        label: 'Número de NOS',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 2,
        type: 'string',
        visible: false
      },
      {
        divider: 'Interação',
        property: 'datint',
        disabled: true,
        label: 'Data da Interação',
        gridXlColumns: 3,
        gridLgColumns: 3,
        gridMdColumns: 3,
        gridSmColumns: 3,
        order: 3,
        type: 'date',
        format: 'mm/dd/yyyy',
        visible: false
      },
      {
        property: 'horint',
        label: 'Hora da Interação',
        gridXlColumns: 3,
        gridLgColumns: 3,
        gridMdColumns: 3,
        gridSmColumns: 3,
        order: 4,
        type: 'time',
        visible: false,
        disabled: true,
      },
      {
        property: 'intera',
        label: 'Interação',
        gridXlColumns: 3,
        gridLgColumns: 3,
        gridMdColumns: 3,
        gridSmColumns: 3,
        order: 5,
        type: 'string',
        disabled: true,
        visible: false
      },
      {
        divider: "NOVA INTERAÇÃO",
        property: 'observ',
        label: 'Observações',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 6,
        type: 'string',
        rows: 4,
        required: true,
        minLength: 5
      },
      {
        property: 'origem',
        label: 'Origem',
        gridColumns: 12,
        gridSmColumns: 12,
        order: 7,
        type: 'string',
        visible: false,
      },
      {
        property: "anexo1",
        label: 'Anexo 1',
        visible: false,
        gridColumns: 12,
        gridSmColumns: 12,
        order: 8,
        type: 'string',
      },
      {
        property: "anexo2",
        label: 'Anexo 2',
        visible: false,
        gridColumns: 12,
        gridSmColumns: 12,
        order: 9,
        type: 'string',
      },
      {
        property: "anexo3",
        label: 'Anexo 3',
        visible: false,
        gridColumns: 12,
        gridSmColumns: 12,
        order: 10,
        type: 'string'
      },
      {
        property: "anexo4",
        label: 'Anexo 4',
        visible: false,
        gridColumns: 12,
        gridSmColumns: 12,
        order: 11,
        type: 'string'
      },
      {
        property: "anexo5",
        label: 'Anexo 5',
        visible: false,
        gridColumns: 12,
        gridSmColumns: 12,
        order: 12,
        type: 'string'
      }
    ];
  }

  getInteracaoDynamicView(): Array<PoDynamicViewField> {
    return [
      {
        property: 'datint',
        label: 'Data',
        visible: true,
        type: 'date',
        gridColumns: 6,
        gridSmColumns: 6,
        order: 1
      },
      {
        property: 'horint',
        label: 'Hora de envio',
        visible: true,
        gridColumns: 6,
        gridSmColumns: 6,
        order: 2
      },
      {
        property: 'observ',
        label: 'Interação',
        gridColumns: 12,
        order: 3
      },
      {
        property: 'imagens',
        type: 'string',
        visible: false
      }
    ]
  }
}
