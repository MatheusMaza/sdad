import { Time } from "@angular/common";

export interface IAnexoBase {
  anexo1?: string;
  anexo2?: string;
  anexo3?: string;
  anexo4?: string;
  anexo5?: string;
}

export interface IAcompanhamento extends IAnexoBase {
    unidad:   string;
    tocorr: string;
    ocoinf: string;
    pesenv: string;
    datoco: string;
    horaocor: string;
    recorr: string;
    cieoco: string;
    sabeoco: string;
    relato: string;
}

export interface IInteracaoAcomp extends IAnexoBase {
    datint: string;
    filial: string;
    horint: string;
    intera: string;
    nosnum: string;
    observ: string;
    origem: string;
    imagens: string[];
    block?: string
}
