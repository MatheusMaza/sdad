import { Component, OnInit, ViewChild } from '@angular/core';
import { PoBreadcrumbItem, PoBreadcrumbModule, PoDynamicFormField, PoDynamicViewComponent, PoDynamicViewField, PoModalAction, PoModalComponent, PoModalModule, PoNotificationService, PoToasterOrientation } from '@po-ui/ng-components';
import { PoDynamicModule } from '@po-ui/ng-components';
import { PoFieldModule } from '@po-ui/ng-components';
import { PoWidgetModule } from '@po-ui/ng-components';
import { FieldsService } from '../../services/fields.service';
import { IPortalFormInterfaceBase, IPortalFormInterfaceView } from '../../interface/dynamicBase';
import { IInteracaoAcomp } from '../../interface/acompanhamento';
import { PoAccordionModule } from '@po-ui/ng-components';
import { PoButtonModule } from '@po-ui/ng-components';
import { PoListViewModule } from '@po-ui/ng-components';
import { PoInfoModule } from '@po-ui/ng-components';
import { TokenService } from '../../services/token.service';
import { catchError, retry } from 'rxjs';
import { OuvidoriaService } from '../../services/ouvidoria.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { PoTagModule } from '@po-ui/ng-components';
import { PoDividerModule } from '@po-ui/ng-components';
import { ImagensComponent } from '../../componentes/imagens/imagens.component';
import { PoDynamicViewBaseComponent } from '@po-ui/ng-components/lib/components/po-dynamic/po-dynamic-view/po-dynamic-view-base.component';

@Component({
  selector: 'app-nova-denuncia',
  standalone: true,
  imports:
  [
    PoModalModule,
    PoDynamicModule,
    PoFieldModule,
    PoWidgetModule,
    PoAccordionModule,
    PoButtonModule,
    PoBreadcrumbModule,
    PoListViewModule,
    PoInfoModule,
    CommonModule,
    FormsModule,
    PoTagModule,
    PoDividerModule,
    ImagensComponent,
  ],
  templateUrl: './acompanhar-denuncia.component.html',
  styleUrl: './acompanhar-denuncia.component.scss'
})
export class acompanharDenuncia implements OnInit{

  modalInserirProtocolo: PoModalAction =
  { label: 'Consultar', action: () => this.consultarProtocolo()};

  opcaoBreadcrumb: PoBreadcrumbItem[] = [
    { label: 'Home', link: '/' },
    { label: 'Relato', link: '/acompanharRelato' }
  ]

  acompanhamentoView!: IPortalFormInterfaceView;
  interacaoForm!: IPortalFormInterfaceBase;
  interacaoMostra: boolean = false;
  lista: Array<any> = [];
  exibeForm: boolean = false;
  protocoloInput: string = "";
  valoresRecuperadados: any = {}
  interacoes: IInteracaoAcomp[] = [];
  requisicaoConsulta: any;
  interacaoDynamicViewField: PoDynamicViewField[] = []
  tituloAccordeonRelato: string = '';
  base64String: string[] = [];
  fields: PoDynamicViewField[] =[];

  deveMostrarInteracao: boolean = true;

  fieldsOpcoes: any;

  @ViewChild('modalProtocolo', {static: true}) modalProtocolo!: PoModalComponent;

  constructor(
    private _DynamicForm: FieldsService,
    private tokenService: TokenService,
    private ouvidoriaService: OuvidoriaService,
    private poNotification: PoNotificationService,
    private routes: Router
  ) {}

  ngOnInit(): void {
    this.modalProtocolo.open();

    this.tokenService.getToken().pipe(
      catchError((err) => {
        console.error(err);
        this.poNotification.error('Não foi possivel recuperar informações, tente novamente em alguns instantes.')
        this.routes.navigate([''])
        return [];
      })
    )
    .subscribe((dataToken: any) => {
      window.sessionStorage.setItem('access_token', dataToken.access_token);
      window.sessionStorage.setItem('refresh_token', dataToken.refresh_token);
      window.sessionStorage.setItem('token_type', dataToken.token_type);
    })

    this.interacaoForm = {
      fields: this._DynamicForm.getinteracoesAcomp(),
      dados: this.interacoes
    };



    this.interacaoDynamicViewField = this._DynamicForm.getInteracaoDynamicView();
  }

  getLabel(options: any[], property: string, code: string): string {
    const filteredOptions = options.filter(option => option.property === property);

    if (filteredOptions.length === 0 || !filteredOptions[0].options) {
      return '';
    }

    const labelOption = filteredOptions[0].options.find((option: any) => option.code.trim() === code.trim());

    return labelOption ? labelOption.label : '';
  }

  async onUploadFiles(event: any) {

    const input = event.target as HTMLInputElement;
    const files = Array.from(input.files || []);
    const maxFiles = 5;

    if (files && files.length > maxFiles) {
        input.value = '';
        this.poNotification.warning('Você pode enviar no máximo 5 arquivos.');

    } else {
      for (const file of files) { // Usei o loop for...of para iterar sobre os arquivos
        if (file) {
            const base64String = await this.readFileAsDataURL(file);
            
            // Verifica se o arquivo é uma imagem ou um PDF
            if (file.type.startsWith('image/') || file.type === 'application/pdf') {
                this.base64String.push(base64String);
            } else {
                this.poNotification.error('Tipo de arquivo não suportado: ' + file.type);
            }
        }
      } 
    }
  }

  readFileAsDataURL(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        resolve(reader.result as string);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  consultarProtocolo(){
     this.ouvidoriaService.consultaRelato(this.protocoloInput.trim()).pipe(
      catchError((err) => {
        console.error(err);
        this.poNotification.error('Não foi possivel consultar seu protocolo')
        this.routes.navigate([''])
        return [];
      })
     ).subscribe((res) => {
      this.valoresRecuperadados = res.reclamacao;
      this.interacoes = res.items;

      this.acompanhamentoView = {
        fields: this._DynamicForm.getViewAcompanhamento(),
        dados: this.valoresRecuperadados
      }
      if (this.acompanhamentoView.fields) {
        const fieldsRelatos = this._DynamicForm.getFieldsRelato();

        this.acompanhamentoView.dados.ocorre = this.getLabel(
          fieldsRelatos,
          "tocorr",
          this.acompanhamentoView.dados.ocorre
        );

        this.acompanhamentoView.dados.unidad = this.getLabel(
          fieldsRelatos,
          "unidad",
          this.acompanhamentoView.dados.unidad
        )
      }

      this.tituloAccordeonRelato = `Detalhes relato protocolo: ${this.valoresRecuperadados.numpro}`
      this.modalProtocolo.close()
      this.exibeForm = true
    })
  }

  gravaInteracao(){
    if(this.base64String.length > 0) {
      for (let i = 0; i < this.base64String.length; i++) {
        this.interacaoForm.dados[`anexo${i + 1}`] = this.base64String[i];
      }
    }
      const payload = {
        origin: "0",
        observ: this.interacaoForm.dados.observ,
        nosnum: this.valoresRecuperadados.nosnum,
        anexo1: this.interacaoForm.dados.anexo1,
        anexo2: this.interacaoForm.dados.anexo2,
        anexo3: this.interacaoForm.dados.anexo3,
        anexo4: this.interacaoForm.dados.anexo4,
        anexo5: this.interacaoForm.dados.anexo5,
      }

      this.resetarFormulario();

      this.ouvidoriaService.gravaInteracao(payload).pipe(
        catchError((err) => {
          console.error(err);
          if(err.error.errorMessage){
            this.poNotification.error(err.error.errorMessage)
            return [];
          } else {
            this.poNotification.error('Não foi possivel gravar sua interação')
            return [];
          }
        })
      ).subscribe((res) => {
        this.poNotification.success({
          message: res.message,
          duration: 3000,
          orientation: PoToasterOrientation.Bottom
        })
        this.getNovoHistorico(this.valoresRecuperadados.numpro)
      })
  }

  getNovoHistorico(numeroProtocolo: string){
    this.ouvidoriaService.consultaRelato(numeroProtocolo).pipe(
      catchError((err) => {
        console.error(err);
        this.poNotification.error('Não foi possivel consultar seu protocolo')
        this.routes.navigate([''])
        return [];
      })
    ).subscribe((res) => {
      this.valoresRecuperadados = res.reclamacao;
      this.interacoes = res.items;

      if(this.valoresRecuperadados.block == "Sim") {
        this.deveMostrarInteracao = false;
      } else {
        this.deveMostrarInteracao = true;
      }
      
      const camposAjustados = this.ajustarCamposParaVisualizacao(
        this._DynamicForm.getViewAcompanhamento(),
        this.valoresRecuperadados
      );

      this.acompanhamentoView = {
        fields: camposAjustados,
        dados: this.valoresRecuperadados
      };

      if (this.acompanhamentoView.fields) {
        const fieldsRelatos = this._DynamicForm.getFieldsRelato();

        this.acompanhamentoView.dados.ocorre = this.getLabel(
          fieldsRelatos,
          "tocorr",
          this.acompanhamentoView.dados.ocorre
        );
        this.acompanhamentoView.dados.unidad = this.getLabel(
          fieldsRelatos,
          "unidad",
          this.acompanhamentoView.dados.unidad
        )
      }

      this.tituloAccordeonRelato = `Detalhes relato protocolo: ${this.valoresRecuperadados.numpro}`
      this.modalProtocolo.close()
      this.exibeForm = true

    })
  }

  ajustarCamposParaVisualizacao(campos: PoDynamicViewField[], dados: any) {
    return campos.map(campo => {
      if (dados[campo.property] === null) {
        return {
          ...campo,
          type: 'string',
          value: 'Não informado'
        };
      }
      return campo;
    });
  }

  resetarFormulario() {
    this.interacaoForm.dados = {};
    this.base64String = [];
  }


  voltarAoTopo() {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    })
  }
}
