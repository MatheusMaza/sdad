export const environment = {
    urlToken: 'http://10.1.100.39:3000/auth/getToken',

    
};

export const recaptcha = {
    siteKey: '6LcHoi8qAAAAAGYDA7RRXBxwq3ACR4ZcVWp07xj2',
}