import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { DenunciaComponent } from './pages/denuncia/denuncia.component';
import { acompanharDenuncia } from './pages/acompanhar-denuncia/acompanhar-denuncia.component';

export const routes: Routes = 
[
    {
        path: '', 
        component: HomeComponent
    },
    {
        path: 'novoRelato', 
        component: DenunciaComponent
    },
    {
        path: 'acompanharRelato', 
        component: acompanharDenuncia
    },
];
