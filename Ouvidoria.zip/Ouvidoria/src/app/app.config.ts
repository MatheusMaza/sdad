import { ApplicationConfig, CUSTOM_ELEMENTS_SCHEMA, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { PoHttpRequestModule } from '@po-ui/ng-components';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { tokenInterceptor } from './interceptors/token.interceptor';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { loaderInterceptor } from './interceptors/loader.interceptor';
import {RECAPTCHA_V3_SITE_KEY, RecaptchaFormsModule, RecaptchaModule, RecaptchaV3Module } from 'ng-recaptcha';

export const appConfig: ApplicationConfig = {
  providers: [ provideRouter(routes),
    provideHttpClient(),
    importProvidersFrom([
      BrowserModule, 
      PoHttpRequestModule, 
      NgOptimizedImage,
      CommonModule, 
      FormsModule, 
      ReactiveFormsModule,
      // RecaptchaModule,
      // RecaptchaFormsModule,
      RecaptchaV3Module,
    ]),
    provideHttpClient(withInterceptors([tokenInterceptor, loaderInterceptor])),
    {provide: RECAPTCHA_V3_SITE_KEY, useValue:'6Lf2rDUqAAAAAD_gtcxPKdQ3PcZ5tuto8Jmflk2L'}
  ],
};


