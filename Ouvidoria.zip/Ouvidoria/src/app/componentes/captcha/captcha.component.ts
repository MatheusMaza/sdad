import { Component, inject } from '@angular/core';
import { RecaptchaModule, ReCaptchaV3Service } from 'ng-recaptcha';

@Component({
  selector: 'app-captcha',
  standalone: true,
  imports: [
    RecaptchaModule
  ],
  templateUrl: './captcha.component.html',
  styleUrl: './captcha.component.scss'
})
export class CaptchaComponent {

  recaptchaService = inject(ReCaptchaV3Service);
  siteKey: string;

  constructor(){
    this.siteKey = '6LftxDUqAAAAAFKg7To43ZS0BdDsWXwRTmJC0jim'
  }
}

