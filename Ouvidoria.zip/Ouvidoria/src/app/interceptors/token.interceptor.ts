import { HttpInterceptorFn } from '@angular/common/http';

export const tokenInterceptor: HttpInterceptorFn = (req, next) => {
  if(!req.headers.get('skip')){
    const token =  window.sessionStorage.getItem('access_token')
    const authReq = req.clone({ headers: req.headers.set ('Authorization', `bearer ${token}`)})
    return next(authReq);
  } else {
    return next(req)
  }
  
};
