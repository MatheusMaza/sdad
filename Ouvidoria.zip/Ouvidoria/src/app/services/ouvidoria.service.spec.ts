import { TestBed } from '@angular/core/testing';

import { OuvidoriaService } from './ouvidoria.service';

describe('OuvidoriaService', () => {
  let service: OuvidoriaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OuvidoriaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
