import { Component, OnInit } from '@angular/core';
import { PoButtonModule } from '@po-ui/ng-components';
import { Router} from '@angular/router';
import {ClipboardModule} from '@angular/cdk/clipboard';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RecaptchaFormsModule, RecaptchaModule } from 'ng-recaptcha';
import { CaptchaComponent } from '../../componentes/captcha/captcha.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    PoButtonModule,
    ClipboardModule,
    RecaptchaFormsModule,
    RecaptchaModule,
    ReactiveFormsModule,
    CaptchaComponent
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit{
  
  protected aFormGroup!: FormGroup;


  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
  ) {}

  ngOnInit() {
    this.aFormGroup = this.formBuilder.group({
      recaptcha: ['', Validators.required]
    });
  }

  denunciar() {
   this.router.navigate(['novoRelato']); 
  }

  acompanharDenuncia() {
    this.router.navigate(['acompanharRelato']);
  }

}
